<footer class="main-footer">
    <strong>Copyright © 
      <script>
        document.write(new Date().getFullYear())
      </script>
      <a href="https://bengkelkoding.dinus.ac.id/">Bengkel Koding</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
</footer>